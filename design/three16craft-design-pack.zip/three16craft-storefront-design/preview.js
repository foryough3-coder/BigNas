(() => {
  "use strict";
  const { products, categories, icons } = window.STOREFRONT_DATA;
  const $ = (id) => document.getElementById(id);
  const escape = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
  const icon = (name, size = 24) => '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + icons[name] + '</svg>';
  const categoryName = (id) => categories.find((c) => c.id === id)?.name || id;
  const imagePath = (key) => "r2-upload/" + key;
  let category = "all", query = "", limit = 8, detailId = null, detailQty = 1;
  let cart = {};
  try {
    const saved = JSON.parse(localStorage.getItem("three16craft-design-cart") || "{}");
    for (const product of products) {
      const n = Number(saved[product.id]);
      if (Number.isInteger(n) && n > 0) cart[product.id] = Math.min(n, 999);
    }
  } catch {}
  function hydrateIcons(root = document) {
    root.querySelectorAll("[data-icon]").forEach((el) => { el.innerHTML = icon(el.dataset.icon); });
  }
  function total() { return Object.values(cart).reduce((sum, n) => sum + n, 0); }
  function persist() {
    try { localStorage.setItem("three16craft-design-cart", JSON.stringify(cart)); } catch {}
    $("cart-count").textContent = total();
    document.querySelector(".cart-trigger").setAttribute("aria-label", "Open cart, " + total() + " items");
  }
  let toastTimer;
  function notify(text) {
    $("toast").textContent = text;
    $("toast").classList.add("visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => $("toast").classList.remove("visible"), 2600);
  }
  function addToCart(id, n = 1, source) {
    cart[id] = Math.min((cart[id] || 0) + n, 999);
    persist();
    notify("Added to your cart");
    if (source) {
      const original = source.innerHTML;
      source.innerHTML = icon("check", 16) + " Added";
      setTimeout(() => { if (source.isConnected) source.innerHTML = original; }, 1100);
    }
  }
  function finishClass(p) { return p.finishLabel.includes("black") ? "black" : p.finishLabel.includes("Gold") ? "gold" : ""; }
  function card(p) {
    return '<article class="product-card"><button class="product-photo" data-product="' + p.id + '" aria-label="View ' + escape(p.name) + '"><img src="' + imagePath(p.thumbnailKey) + '" width="480" height="480" loading="lazy" decoding="async" alt="' + escape(p.alt) + '"><span class="photo-open">' + icon("arrow-right", 14) + '</span></button><div class="product-info"><p class="product-category">' + categoryName(p.category) + '</p><button class="product-name" data-product="' + p.id + '">' + escape(p.name) + '</button><p class="finish"><span class="finish-dot ' + finishClass(p) + '"></span>' + escape(p.finishLabel) + '</p><div class="product-actions"><button class="button add-button" data-add="' + p.id + '" aria-label="Add ' + escape(p.name) + ' to cart">' + icon("plus", 16) + ' Add to cart</button><button class="button wa-button" data-enquire="' + p.id + '" aria-label="Enquire about ' + escape(p.name) + ' on WhatsApp">' + icon("whatsapp", 16) + ' WhatsApp</button></div></div></article>';
  }
  function renderProducts() {
    let results = products.filter((p) => (category === "all" || p.category === category) && (p.name + " " + p.finishLabel + " " + categoryName(p.category)).toLowerCase().includes(query.toLowerCase()));
    if ($("sort").value === "name") results.sort((a,b) => a.name.localeCompare(b.name));
    const shown = results.slice(0, limit);
    $("product-grid").innerHTML = shown.length ? shown.map(card).join("") : '<div class="empty-results"><h3>No matching products</h3><p>Try a different search or clear your filters.</p></div>';
    $("result-count").textContent = "Showing " + shown.length + " of " + results.length + " products";
    $("show-more").hidden = results.length <= limit;
    $("show-more").parentElement.hidden = results.length <= limit;
    $("reset").hidden = category === "all" && !query;
    $("filter-tabs").innerHTML = [{id:"all",name:"All products"}, ...categories].map((c) => '<button class="filter-tab' + (c.id === category ? ' active' : '') + '" data-filter="' + c.id + '" aria-pressed="' + (c.id === category) + '">' + c.name + '</button>').join("");
  }
  function setCategory(id, resetQuery) {
    category = id; limit = products.length;
    if (resetQuery) { query = ""; $("search").value = ""; }
    renderProducts();
  }
  function quantityMarkup(id, value, detail = false) {
    const attr = detail ? 'data-detail-qty' : 'data-cart-qty';
    return '<div class="quantity"><button ' + attr + '="-1" data-id="' + id + '" aria-label="Decrease quantity"' + (value <= 1 ? ' disabled' : '') + '>' + icon("minus",16) + '</button><output aria-label="Quantity">' + value + '</output><button ' + attr + '="1" data-id="' + id + '" aria-label="Increase quantity"' + (value >= 999 ? ' disabled' : '') + '>' + icon("plus",16) + '</button></div>';
  }
  function renderDetail() {
    const p = products.find((p) => p.id === detailId);
    if (!p) return;
    $("product-detail").innerHTML = '<div class="product-detail-layout"><div class="detail-photo"><img src="' + imagePath(p.imageKey) + '" width="1000" height="1000" alt="' + escape(p.alt) + '"></div><div class="detail-copy"><p class="eyebrow">' + categoryName(p.category) + '</p><h2 id="product-dialog-title">' + escape(p.name) + '</h2><p class="description">' + escape(p.description) + '</p><p class="finish"><span class="finish-dot ' + finishClass(p) + '"></span>' + escape(p.finishLabel) + '</p><div id="detail-quantity">' + quantityMarkup(p.id, detailQty, true) + '</div><div class="detail-buttons"><button class="button primary" data-detail-add="' + p.id + '">' + icon("cart",18) + ' Add to cart</button><button class="button secondary" data-detail-enquire="' + p.id + '">' + icon("whatsapp",18) + ' Ask on WhatsApp</button></div><p class="detail-note">Ask us to confirm dimensions, fitting compatibility and what is included for your project.</p></div></div>';
  }
  function openProduct(id) {
    detailId = id; detailQty = 1; renderDetail(); $("product-dialog").showModal();
  }
  function renderCart() {
    const entries = products.filter((p) => cart[p.id]);
    if (!entries.length) {
      $("cart-content").innerHTML = '<div class="empty-cart">' + icon("cart",40) + '<h3>Your next project starts here.</h3><p>Add products to build your selection.</p><button class="button primary" data-close="cart-dialog">Explore the collection</button></div>';
      return;
    }
    $("cart-content").innerHTML = entries.map((p) => '<div class="cart-line"><img src="' + imagePath(p.thumbnailKey) + '" width="74" height="88" alt="' + escape(p.name) + '"><div><h3>' + escape(p.name) + '</h3><span class="finish">' + escape(p.finishLabel) + '</span>' + quantityMarkup(p.id, cart[p.id]) + '</div><button data-remove="' + p.id + '" aria-label="Remove ' + escape(p.name) + ' from cart">' + icon("trash",18) + '</button></div>').join("") + '<div class="cart-summary"><p class="item-total">' + total() + ' item' + (total() === 1 ? '' : 's') + ' in your selection</p><p>Share your list with us to confirm the details, availability and pricing.</p><button class="button primary" data-action="cart-enquiry">' + icon("whatsapp",18) + ' Enquire about your cart</button></div>';
  }
  function showEnquiry(message) {
    $("product-dialog").close(); $("cart-dialog").close();
    $("enquiry-message").value = message;
    $("copy-enquiry").textContent = "Copy message";
    $("enquiry-dialog").showModal();
  }
  function productEnquiry(id, qty = 1) {
    const p = products.find((p) => p.id === id);
    showEnquiry("Hello three16craft, I’m interested in:\n\n" + p.name + "\nFinish shown: " + p.finishLabel + "\nQuantity: " + qty + "\n\nPlease confirm the available sizes, compatibility, availability and price.\n\nProduct reference: " + p.id);
  }
  document.addEventListener("click", (event) => {
    const target = event.target.closest("button,a");
    if (!target) return;
    const d = target.dataset;
    if (d.category) setCategory(d.category, true);
    else if (d.filter) setCategory(d.filter, false);
    else if (d.product) openProduct(d.product);
    else if (d.add) addToCart(d.add, 1, target);
    else if (d.enquire) productEnquiry(d.enquire);
    else if (d.detailAdd) addToCart(d.detailAdd, detailQty, target);
    else if (d.detailEnquire) productEnquiry(d.detailEnquire, detailQty);
    else if (d.detailQty) {
      detailQty = Math.max(1, Math.min(999, detailQty + Number(d.detailQty)));
      const focusDelta = d.detailQty;
      $("detail-quantity").innerHTML = quantityMarkup(detailId, detailQty, true);
      const next = $("detail-quantity").querySelector('[data-detail-qty="' + focusDelta + '"]');
      if (next && !next.disabled) next.focus();
    }
    else if (d.cartQty) {
      cart[d.id] = Math.max(1, Math.min(999, cart[d.id] + Number(d.cartQty)));
      persist(); renderCart();
      const next = $("cart-content").querySelector('[data-id="' + d.id + '"][data-cart-qty="' + d.cartQty + '"]');
      if (next && !next.disabled) next.focus();
    }
    else if (d.remove) { delete cart[d.remove]; persist(); renderCart(); }
    else if (d.close) $(d.close).close();
    else if (d.action === "cart") { renderCart(); $("cart-dialog").showModal(); }
    else if (d.action === "cart-enquiry") {
      const items = products.filter((p) => cart[p.id]).map((p) => "• " + p.name + " — quantity " + cart[p.id]).join("\n");
      showEnquiry("Hello three16craft, please help with the following items:\n\n" + items + "\n\nPlease confirm available sizes, compatibility, availability and pricing.\n\nProject details:\n");
    } else if (d.action === "project-enquiry") {
      showEnquiry("Hello three16craft, I’d like help choosing hardware for my project.\n\nProject type:\nItems I’m considering:\nApproximate quantities:\nMeasurements or specifications:\n");
    }
  });
  $("search").addEventListener("input", () => { query = $("search").value.trim(); limit = products.length; renderProducts(); });
  $("search-form").addEventListener("submit", (e) => { e.preventDefault(); $("collection").scrollIntoView(); });
  $("sort").addEventListener("change", renderProducts);
  $("reset").addEventListener("click", () => setCategory("all", true));
  $("show-more").addEventListener("click", () => { limit = products.length; renderProducts(); });
  $("copy-enquiry").addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText($("enquiry-message").value);
      $("copy-enquiry").textContent = "Message copied";
    } catch {
      $("enquiry-message").focus(); $("enquiry-message").select();
      $("copy-enquiry").textContent = "Select and copy the message";
    }
  });
  let paused = matchMedia("(prefers-reduced-motion: reduce)").matches;
  function setMotion() {
    $("brand-picture").querySelector("source").srcset = paused ? "r2-upload/three16craft/brand/v1/logo-static.png" : "r2-upload/three16craft/brand/v1/logo-animated.gif";
    $("brand-logo").src = "r2-upload/three16craft/brand/v1/" + (paused ? "logo-static.png" : "logo-animated.gif");
    $("motion-toggle").innerHTML = icon(paused ? "play" : "pause",14) + (paused ? " Play logo animation" : " Pause logo animation");
    $("motion-toggle").setAttribute("aria-pressed", String(paused));
  }
  $("motion-toggle").addEventListener("click", () => { paused = !paused; setMotion(); });
  matchMedia("(prefers-reduced-motion: reduce)").addEventListener("change", (event) => { paused = event.matches; setMotion(); });
  $("category-grid").innerHTML = categories.map((c) => {
    const count = products.filter((p) => p.category === c.id).length;
    return '<a class="category-tile" href="#collection" data-category="' + c.id + '">' + icon(c.icon,32) + '<b>' + c.name + '</b><small>' + count + (count === 1 ? ' product' : ' products') + '</small></a>';
  }).join("");
  hydrateIcons(); persist(); renderProducts(); setMotion();
})();
