# three16craft storefront design pack

Open preview.html to review the desktop/mobile storefront. It works directly from this folder without installing dependencies.

## Included

- UI-PLAN.md: arrangement, visual system, product flow and implementation map for the existing Next.js project.
- preview.html, preview.css, refinements.css, preview.js, catalog.js and design-tokens.css: interactive design preview.
- icons.html and icons/: 28 SVG icons, a sprite and a typed React component.
- hero-banner-master.png: full-resolution product banner.
- BANNER-PROMPT.md: exact prompt and reference description; created with built-in ImageGen.
- catalog-draft.json: 13 provisional product entries and six categories; all prices are null.
- r2-upload/: optimized image exports and the original animated GIF logo.
- r2-manifest.json and R2-UPLOAD.md: object keys, metadata and upload handoff.
- preview-desktop.png, preview-mobile.png, preview-mobile-full.png and preview-product.png: verified screen previews.
- icon-library.png: icon overview.
- verification.json: focused preview check results.

Try searching, choosing a category, opening a product, changing quantities, adding to cart and reviewing a WhatsApp enquiry draft. Prices are omitted as requested. The cart persists only within this preview.

WhatsApp buttons demonstrate prefilled messages. They do not contact anyone until the real business number is configured in the production application.

The animated GIF remains the header logo. A static fallback and pause control support reduced motion. Screenshots use the static fallback so the brand is clearly visible.

All deliverables are self-contained here. No changes have been made to the existing application or the R2 bucket.


## Latest refinement

One font family, Geist, is locally bundled and used across the whole UI. The header,
hero type, category tiles, product cards, action hierarchy, filters and enquiry
layouts have been retouched. fonts/OFL.txt contains the font license.

preview-desktop-top.png and preview-cart.png supplement the full-page screenshots.
The R2 upload manifest still contains the same 29 image assets; serve the small
font file with the app.
