# three16craft icons

28 original SVG icons: 22 interface icons and 6 product category icons.
24 × 24 viewBox, 1.75px stroke, round joins, currentColor, no external dependency.

Use Icon.tsx for Next.js/React. Example:
<button aria-label="Open cart"><Icon name="cart" /></button>

Use 20–24px for controls, 32px for category tiles. Keep button targets at least 44 × 44px.
The WhatsApp action uses a phone-in-chat pictogram, not an official WhatsApp brand mark.

sprite.svg symbols need these attributes on the enclosing SVG:
fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round".
