# R2 asset handoff

All upload assets are in r2-upload/three16craft. Preserve that path structure as object keys.

## Ready assets

| Folder | Contents |
|---|---|
| three16craft/brand/v1 | logo-animated.gif, logo-static.png |
| three16craft/banners/v1 | hero-desktop.webp |
| three16craft/products/v1 | 480px and 1000px WebP versions of all 13 product photos |

r2-manifest.json is the complete upload list, including MIME types, dimensions, SHA-256 checksums and recommended Cache-Control metadata.

## Upload and connect

1. Choose the R2 bucket intended for public catalog assets.
2. Upload each file with the exact key shown in the manifest.
3. Preserve image/gif for the animated logo, image/png for its static fallback and image/webp for product images and the hero.
4. Set Cache-Control to public, max-age=31536000, immutable for these versioned objects. When an image changes, publish it under a new version key instead of silently replacing a cached asset.
5. Connect the production asset domain to the bucket. Use that domain as the application’s asset base URL.
6. Set the Next.js remote image allowlist to this exact host and /three16craft/**.
7. Fetch a product image and the logo from the public URLs; verify content type, caching, dimensions and GIF animation.

Production should use a custom domain; r2.dev is a development endpoint with rate limits. [Cloudflare’s public bucket guidance](https://developers.cloudflare.com/r2/buckets/public-buckets/)

Example URL shape, using a placeholder domain only:

    https://YOUR-ASSET-DOMAIN/three16craft/products/v1/square-base-glass-spigot-1000.webp
    https://YOUR-ASSET-DOMAIN/three16craft/brand/v1/logo-animated.gif

Do not convert the primary logo to a still image. Use the supplied static PNG only for motion preferences, a pause control or a fallback. When using next/image for the GIF, explicitly keep it unoptimized.

The application needs the public asset base URL. Upload credentials belong in server-side configuration or the uploader, never public browser environment variables.

CORS is only needed for browser requests that require it, such as direct uploads or canvas/fetch processing; configure allowed origins and methods for those uses. [R2 CORS documentation](https://developers.cloudflare.com/r2/buckets/cors/)

## Information still needed

- R2 bucket name and production public asset domain.
- Store WhatsApp number in international format.
- The future public website URL, for product links in enquiry messages.

The package has not been uploaded. The preview loads the packaged files locally and makes no external requests.
