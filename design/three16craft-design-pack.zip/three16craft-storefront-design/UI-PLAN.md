# three16craft — storefront UI plan

Prepared 22 September 2026 for the existing project at C:/Users/korsa/Desktop/BIG_NAS/ecommerce-app.

## Agreed direction

A classic architectural hardware storefront: white product photography, a warm ivory banner, restrained blue navigation, muted red primary actions, and one consistent Geist type family throughout. The animated GIF remains the main header logo.

**Prices will be added later.** Customers can add items and quantities to a cart and enquire through WhatsApp. Each product card and product detail page has a WhatsApp button. The cart shows item counts, without prices, subtotals, shipping estimates or a grand total.

The design preview is a local, interactive prototype. It demonstrates search, category filtering, product details, quantities, cart persistence and enquiry messages. It does not send WhatsApp messages or place orders. The existing application has been inspected; this package is a design and asset handoff, not an application deployment.

## Homepage arrangement

| Order | Section | Content and behavior |
|---|---|---|
| 1 | Small utility strip | “Architectural hardware & finishing details” and a project-help link. No unverified delivery or warranty promises. |
| 2 | Main header | Animated three16craft logo at left, prominent search in the middle, cart with quantity count at right. |
| 3 | Category navigation | All products, Glass spigots, Handrail fittings, Glass clamps, Door hardware, Finials, Accessories. |
| 4 | Product banner | The prepared product composition on ivory; live headline “Every detail. Beautifully finished.” Primary action: Explore products. Secondary: Plan your project. |
| 5 | Category shortcuts | Six consistent line icons, clear category labels and the number of catalog entries. |
| 6 | Product collection | Eight initial products in a four-column desktop grid; category filters and a View all products control expose all 13 entries. |
| 7 | Project enquiry section | A simple three-step explanation: explore, build your cart, enquire on WhatsApp. |
| 8 | Footer | Brand, category links, WhatsApp contact and an animation pause control. Add verified address, opening hours and policy links when supplied. |

The hero is one composition rather than an auto-rotating carousel. Copy stays in HTML so it remains readable, accessible and editable. Its product group uses a representative selection of the earlier photography; all 13 processed images appear in the catalog.

## Catalog structure

The draft names and groupings are based on visible products. Confirm final trade names and sellable units before launch.

| Category | Entries | Products |
|---|---:|---|
| Glass spigots | 3 | Square-base silver, round-base silver, matte black |
| Handrail fittings | 3 | Elbow fitting, curved bracket, adjustable support bracket |
| Glass clamps | 1 | Rounded clamp |
| Door hardware | 2 | Roller hardware set, long door handle set |
| Finials | 1 | Gold / silver ball finials |
| Mounting accessories | 3 | Slotted cylindrical fitting, cover flange, glass standoff |

The finials image contains two finishes, and several images contain multiple components. Photography alone does not establish whether these are sold individually, as variants, or as complete sets. Until confirmed, keep the descriptive entry and let the customer enquire.

## Product cards and detail pages

Cards show the complete product on a white background, followed by category, product name and visible finish. Keep equal image areas, use object-fit: contain, and avoid cropping long handles or small accessories. Both “Add to cart” and “WhatsApp” are visible actions; opening the image or name reveals details.

The full product route should use the existing /products/[id] structure:

1. Breadcrumbs and a two-column gallery/details layout.
2. Product name, category, finish, short factual description.
3. Confirmed size/finish variants, if applicable, before adding to the cart.
4. Quantity selector, Add to cart, and Ask on WhatsApp.
5. Specifications: dimensions, material grade, compatible glass/rail sizes, fixing method and included components, only when confirmed.
6. Related products from the same category.

On mobile, stack the photo above the details and keep the two actions easy to reach. The prototype uses a product dialog for fast review; production should retain shareable product URLs.

The banner and earlier product photos were AI-assisted. Check them against actual stock for construction, hole positions and finishes before publication. Do not infer 316 stainless steel or any other material grade from the brand name.

## Cart and WhatsApp behavior

The cart is a saved selection for enquiries at this stage. It contains product names, finish or selected variant, quantities and removal controls. Its primary action is “Enquire about your cart.”

Each product WhatsApp message should include the product name, SKU when available, selected variant, quantity and the public product URL. A cart enquiry should list each selected product and quantity, followed by space for project details. For very large selections, keep the message compact and offer a copyable item list instead of an excessively long URL.

Production click-to-chat links use the business number in international digits-only form and URL-encoded message text. Opening a link prepares the message; the customer chooses whether to send it. [WhatsApp’s click-to-chat documentation](https://faq.whatsapp.com/5913398998672934)

The business WhatsApp number has not been provided. The preview therefore shows the exact draft and a Copy message action. Connect the real number during implementation; do not use a guessed number or a nonfunctional link.

When prices arrive, add validated amounts and currency to the catalog, then introduce price sorting and totals. An absent price must stay null, not zero. Keep the enquiry action available even after prices are displayed. Payment checkout is a later decision.

## Visual system

| Token | Value | Use |
|---|---|---|
| Paper | #FFFFFF | Product images and main surfaces |
| Ivory | #F7F5F0 | Hero and footer |
| Brand blue | #456B87 | Category icons and secondary accents |
| Deep blue | #243F50 | Navigation, headings and WhatsApp actions |
| Muted red | #B54C46 | Main calls to action |
| Text | #252C30 | Main body copy |
| Secondary text | #636A6C | Descriptions and supporting text |
| Divider | #E1E3E0 | Fine borders |

Use Geist throughout: headings, navigation, body text, product cards, buttons and dialogs. The same family is used at 400 for body text, 500 for headings and 550–600 for emphasis. The local font is bundled in fonts/geist-latin.woff2, with its Open Font License. It loads without an external font service. Remove the current app's Arial override when applying the design.

Use a 1280px content width, deliberate section spacing, 6px control radii, 8px product-card corners and fine borders. Avoid heavy card shadows and excessive pills. The logo and photography provide the character.

The prepared icon set has 28 SVG icons: 22 interface icons and six hardware category icons. All use a 24 × 24 viewBox, 1.75px strokes and currentColor. SVG files, a sprite and a typed Icon.tsx component are included. The WhatsApp action uses a phone-in-chat pictogram.

## Responsive and accessible behavior

- Desktop: wide hero with live copy at left, six category shortcuts, four product columns and a cart drawer.
- Tablet: three product columns, categories in a 3 × 2 grid, horizontally scrollable navigation.
- Mobile: logo and cart above search, horizontal category navigation, hero text above the product group, two product columns and stacked card actions.
- Preserve the hero product group on mobile with a right-aligned crop; do not place copy over the products.
- Keep input and main action targets at least 44px high. Use clear keyboard focus, meaningful button labels and alt text.
- Honor reduced-motion preferences using the supplied static logo, and provide a pause/play control for the looping GIF.
- Use a fixed light catalog theme initially. The current automatic dark palette would need a separate design pass.

## Integration into the existing application

The inspected app uses Next.js 16.3.5, React 19, Tailwind 4 and TypeScript. It already contains a header, product cards, product detail routes, cart context and a cart page. Products currently use sample lifestyle data, dollar prices and picsum images. Checkout is disabled.

| Existing area | Planned change |
|---|---|
| src/app/layout.tsx | three16craft metadata, consistent Geist font, branded shell and footer |
| src/app/globals.css | Shared design tokens, light surfaces, responsive spacing and visible focus states |
| src/components/Header.tsx | GIF BrandLogo, search field, category navigation, cart count |
| src/app/page.tsx | HeroBanner, CategoryGrid, FeaturedProducts and ProjectEnquiry sections |
| src/components/ProductCard.tsx | Real photography with contain sizing, finish label, Add to cart and WhatsApp |
| src/app/products/[id]/page.tsx | Product gallery, confirmed specifications, quantity, variant support and product enquiry |
| src/components/AddToCartButton.tsx | Quantity and variant-aware addition, accessible confirmation |
| src/context/cart-context.tsx | Store IDs/variant IDs and quantities; hydrate against the current catalog; omit monetary totals while prices are absent |
| src/components/CartItemRow.tsx and src/app/cart/page.tsx | Selection list and WhatsApp enquiry summary without totals or checkout |
| src/lib/products.ts | Replace samples with confirmed hardware data; nullable prices, asset keys and optional specifications |
| next.config.ts | Replace picsum allowance with the exact R2 custom domain and /three16craft/** path |

Suggested small shared components: BrandLogo, Icon, WhatsAppButton, QuantitySelector, HeroBanner and CategoryGrid. Keep catalog rendering on the server where practical, with client components for search/filter controls, cart and logo motion settings.

Version the cart storage key when replacing the sample catalog so previously stored sample products do not appear in the new store. Reconcile stored quantities against known product and variant IDs.

Read the installed Next.js documentation before implementation, as the repository’s AGENTS.md requires. Relevant local image, CSS and font guides were consulted for this plan.

## Cloudflare R2 asset plan

The r2-upload folder contains 29 assets, about 1.27 MiB in total:

- 13 product thumbnails at 480 × 480 WebP.
- 13 product detail images at 1000 × 1000 WebP.
- One 1851 × 850 WebP hero, approximately 78 KB.
- The original 960 × 320 animated GIF, approximately 555 KB.
- One 960 × 320 static PNG logo.

Use a production custom asset domain for the public catalog. Cloudflare documents r2.dev as intended for development, with rate limits; custom domains enable caching. [Cloudflare R2 public buckets](https://developers.cloudflare.com/r2/buckets/public-buckets/)

Use the supplied r2-manifest.json as the upload map. It records each object key, dimensions, content type, cache control, byte size and checksum. Assets are versioned under three16craft/brand/v1, three16craft/banners/v1 and three16craft/products/v1.

Keep the logo as image/gif and bypass image optimization that could flatten it. Set explicit dimensions to avoid layout movement, with the static PNG for reduced motion. Use responsive product image sizes and lazy loading below the fold; load the hero eagerly.

For Next Image, allow only the confirmed asset host and path. The public asset base URL is configuration; upload credentials must remain server-side. Public image display alone does not require a browser upload flow. If direct browser uploads are later introduced, configure CORS for the specific site origins and methods. [Cloudflare R2 CORS](https://developers.cloudflare.com/r2/buckets/cors/)

No R2 upload or DNS changes have been made. See R2-UPLOAD.md for the handoff.

## Implementation order

1. Confirm product names, sellable units, variants, specifications and the business WhatsApp number. Prices are intentionally deferred.
2. Upload the prepared assets and provide the public R2 asset domain.
3. Apply the brand shell, navigation, homepage arrangement and prepared icons.
4. Replace sample data and update product pages, cart storage and enquiry links.
5. Verify mobile layout, keyboard operation, missing/empty search states, quantity changes, actual WhatsApp links, image loading and GIF motion controls.
6. Add verified contact and policy information before publication.

## Preview verification

Checked in Chromium at 1440px desktop and 390px mobile widths: no page errors, no missing initial images and no page-wide horizontal overflow. Search, category filtering, add-to-cart, quantity changes and product/cart enquiry contents were checked. The reduced-motion setting uses the static logo. Desktop, mobile, cart and product-detail screenshots are included. The retouch also verifies Geist loading and layout overflow at 320, 360, 768, 1024 and 1920px.

The original application has not been modified or deployed. Product data remains a draft and business integration details remain to be supplied.


## Retouch 02 — one-font refinement

- Geist is now the actual locally loaded typeface throughout, including the icon library.
- A more compact header gives search and cart clearer alignment.
- The two-tone hero headline uses the existing blue palette and shorter copy.
- Category tiles use aligned icons, subtle borders and directional cues.
- Product cards have consistent frames, image proportions, spacing and button placement.
- Add to cart uses a solid deep-blue button; WhatsApp uses a quiet outlined button.
- Filters use a red underline instead of filled tabs to reduce visual weight.
- Project guidance, cart and product dialogs use the same spacing and typography.
- Mobile keeps two product columns and 44px product action targets.

The font is an application asset; the existing R2 image manifest is unchanged.
